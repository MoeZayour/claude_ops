1.0.2
=====
- Improved access rights handling.
- General bug fixes and performance improvements.

1.0.1
=====
- Minor bug fixes.
- UI and stability improvements.

1.0
=======
- Initial version.
