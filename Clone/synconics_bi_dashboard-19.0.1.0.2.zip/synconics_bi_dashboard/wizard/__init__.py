# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from . import dashboard_access
from . import mail_compose_message
