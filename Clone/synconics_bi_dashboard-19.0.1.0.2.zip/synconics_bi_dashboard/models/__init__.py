from . import ir_model
from . import ir_ui_menu
from . import res_users
from . import list_field
from . import dashboard_action
from . import dashboard
from . import dashboard_chart
